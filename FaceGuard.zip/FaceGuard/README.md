# FaceGuard (Android, Kotlin)

Face-based guard for your own phone. When a face that is not yours looks at the screen, the app:
1. saves the stranger's photo (app-private storage: `files/intruders/`)
2. presses Home (closes the running app)
3. shows a full-screen red warning page: "आप इस मोबाइल को इस्तेमाल नहीं कर सकते"
4. plays a loud alarm and speaks: "मालिक, आप कहाँ हैं? देखो, कौन आपके मोबाइल को हाथ लगा रहा है!"

A small red dot stays on top of every screen while the guard is running.
The warning closes with your PIN, or automatically when your own face is seen again.

## Setup

1. Open the `FaceGuard` folder in Android Studio (Hedgehog or newer) and let Gradle sync.
2. **Add the face model.** Download any MobileFaceNet TFLite model
   (input 112x112x3 float, output 192 floats) and save it as
   `app/src/main/assets/mobilefacenet.tflite`
   (create the `assets` folder if it does not exist). Without it the app crashes on start.
3. Run on a real Android phone (Android 8.0+). The emulator camera is not good for this.
4. In the app, do steps 1 to 6 from top to bottom, then press "गार्ड चालू करें".

## Tuning

`GuardService.kt`:
- `THRESHOLD` (0.55): raise it if strangers get through, lower it if the app flags you.
  Check Logcat tag `FaceGuard` for the live `match score`.
- `STRANGER_FRAMES` (3): number of consecutive stranger frames before the alert (about 2 seconds).
- Enroll in good light, and again with glasses on or off if you use them.

## Known limits

- Android allows camera use only while the screen is on, and a camera foreground service
  must be started while the app is visible. After a reboot, open the app once and press start.
- Android shows a green camera dot while the camera is active. This cannot be hidden.
- Anyone who knows how can stop the app from Settings. This is a deterrent on top of your normal
  phone lock, not a replacement for it.
- A printed photo of you can fool plain face matching. A blink/liveness check is the next step.
- The accessibility service is used only to press Home. Google Play restricts this use,
  so this app is for personal installation (sideload), not for the Play Store.
