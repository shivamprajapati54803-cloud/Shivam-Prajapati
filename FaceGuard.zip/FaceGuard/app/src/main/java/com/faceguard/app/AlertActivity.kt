package com.faceguard.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.lang.ref.WeakReference
import java.util.Locale

/** Full-screen red warning with alarm and voice. Closes with the owner's PIN or when the owner's face is seen. */
class AlertActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var pinInput: EditText
    private lateinit var info: TextView
    private var listening = false

    private val micPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) voiceUnlock()
        }

    private val speakLoop = object : Runnable {
        override fun run() {
            if (ttsReady) {
                tts?.speak(MESSAGE_VOICE, TextToSpeech.QUEUE_FLUSH, null, "alert")
            }
            handler.postDelayed(this, 7000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        active = true
        ref = WeakReference(this)

        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* blocked */ }
        })

        buildUi()
        tts = TextToSpeech(this, this)
        startAlarm()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#B00020"))
            setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "⚠️"
            textSize = 72f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "आप इस मोबाइल को\nइस्तेमाल नहीं कर सकते"
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        info = TextView(this).apply {
            text = "आपकी फोटो खींच ली गई है"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 48)
        }
        root.addView(info)

        pinInput = EditText(this).apply {
            hint = "मालिक का PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#FFCDD2"))
            gravity = Gravity.CENTER
        }
        root.addView(pinInput)
        root.addView(Button(this).apply {
            text = "खोलो"
            setOnClickListener {
                if (Store.checkPin(this@AlertActivity, pinInput.text.toString())) {
                    finish()
                } else {
                    pinInput.setText("")
                    info.text = "गलत PIN! अलार्म चालू रहेगा"
                }
            }
        })
        if (Store.hasVoice(this)) {
            root.addView(Button(this).apply {
                text = "🎤 आवाज़ से खोलो"
                setOnClickListener { voiceUnlock() }
            })
        }
        setContentView(root)
    }

    /** Backup for a wrong face match: owner speaks the saved phrase. */
    private fun voiceUnlock() {
        if (listening) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            micPerm.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        listening = true
        // quiet the alarm and voice so they do not end up in the recording
        handler.removeCallbacks(speakLoop)
        tts?.stop()
        player?.runCatching { pause() }
        info.text = "🎤 बोलिए... (3 सेकंड)"

        Thread {
            val pcm = VoicePrint.record()
            val ok = pcm != null && VoicePrint.matches(this, pcm)
            runOnUiThread {
                listening = false
                if (ok) {
                    finish()
                } else {
                    info.text = "आवाज़ नहीं मिली। फिर कोशिश करें या PIN डालें"
                    player?.runCatching { start() }
                    handler.postDelayed(speakLoop, 3000)
                }
            }
        }.start()
    }

    private fun startAlarm() {
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            am.setStreamVolume(
                AudioManager.STREAM_ALARM,
                am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0
            )
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@AlertActivity, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (_: Exception) {
        }
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val t = tts ?: return
        val res = t.setLanguage(Locale("hi", "IN"))
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            t.setLanguage(Locale.getDefault())
        }
        t.setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
        )
        ttsReady = true
        handler.post(speakLoop)
    }

    override fun onDestroy() {
        active = false
        ref = null
        handler.removeCallbacksAndMessages(null)
        tts?.stop()
        tts?.shutdown()
        player?.runCatching { stop(); release() }
        super.onDestroy()
    }

    companion object {
        @Volatile
        var active = false
        private var ref: WeakReference<AlertActivity>? = null

        private const val MESSAGE_VOICE = "मालिक, आप कहाँ हैं? देखो, कौन आपके मोबाइल को हाथ लगा रहा है!"

        fun dismissFromService() {
            ref?.get()?.runOnUiThread { ref?.get()?.finish() }
        }
    }
}
