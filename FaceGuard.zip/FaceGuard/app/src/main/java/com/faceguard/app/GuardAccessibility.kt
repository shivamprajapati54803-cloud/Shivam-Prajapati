package com.faceguard.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** Used only to press "Home" so the stranger's running app gets closed. Reads no screen content. */
class GuardAccessibility : AccessibilityService() {

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    companion object {
        @Volatile
        var instance: GuardAccessibility? = null

        fun goHome() {
            instance?.performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }
}
