package com.faceguard.app

import android.content.Context
import java.security.MessageDigest
import java.util.UUID

/** Owner face embeddings and PIN hash, kept in private app storage. */
object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("faceguard", Context.MODE_PRIVATE)

    fun saveOwner(c: Context, embeddings: List<FloatArray>) {
        val s = embeddings.joinToString("|") { e -> e.joinToString(",") }
        prefs(c).edit().putString("owner", s).apply()
    }

    fun loadOwner(c: Context): List<FloatArray> {
        val s = prefs(c).getString("owner", null) ?: return emptyList()
        return s.split("|").filter { it.isNotEmpty() }.map { row ->
            row.split(",").map { it.toFloat() }.toFloatArray()
        }
    }

    fun hasOwner(c: Context) = loadOwner(c).isNotEmpty()

    // Voice templates: recordings separated by '#', frames by '|', values by ','
    fun saveVoice(c: Context, templates: List<Array<FloatArray>>, threshold: Float) {
        val s = templates.joinToString("#") { rec ->
            rec.joinToString("|") { fr -> fr.joinToString(",") }
        }
        prefs(c).edit().putString("voice", s).putFloat("voice_thr", threshold).apply()
    }

    fun loadVoice(c: Context): Pair<List<Array<FloatArray>>, Float>? {
        val s = prefs(c).getString("voice", null) ?: return null
        val thr = prefs(c).getFloat("voice_thr", 0f)
        val t = s.split("#").filter { it.isNotEmpty() }.map { rec ->
            rec.split("|").filter { it.isNotEmpty() }.map { fr ->
                fr.split(",").map { it.toFloat() }.toFloatArray()
            }.toTypedArray()
        }
        return if (t.isEmpty()) null else Pair(t, thr)
    }

    fun hasVoice(c: Context) = loadVoice(c) != null

    fun setPin(c: Context, pin: String) {
        val salt = UUID.randomUUID().toString()
        prefs(c).edit().putString("pin", "$salt:${hash(pin, salt)}").apply()
    }

    fun hasPin(c: Context) = prefs(c).getString("pin", null) != null

    fun checkPin(c: Context, pin: String): Boolean {
        val stored = prefs(c).getString("pin", null) ?: return false
        val (salt, h) = stored.split(":", limit = 2)
        return hash(pin, salt) == h
    }

    private fun hash(pin: String, salt: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }
}
