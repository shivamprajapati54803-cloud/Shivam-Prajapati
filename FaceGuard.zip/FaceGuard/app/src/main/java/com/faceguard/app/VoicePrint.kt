package com.faceguard.app

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import java.util.Arrays
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Simple on-device voice check, no model file needed.
 * The owner records the same short phrase 3 times. Each recording becomes MFCC features,
 * and a new recording is compared with them using DTW (dynamic time warping).
 * The threshold is calibrated from the owner's own 3 recordings.
 */
object VoicePrint {
    private const val RATE = 16000
    private const val SECONDS = 3
    private const val FRAME = 400
    private const val HOP = 160
    private const val NFFT = 512
    private const val MELS = 26
    private const val COEFS = 13 // c1..c12 are used
    private const val TAG = "FaceGuard"

    /** Threshold = worst distance between the owner's own recordings x this margin. Tune 1.2 to 1.8. */
    private const val MARGIN = 1.4f

    // ------------------------------------------------------------ recording

    @SuppressLint("MissingPermission")
    fun record(): ShortArray? {
        val total = RATE * SECONDS
        val minBuf = AudioRecord.getMinBufferSize(
            RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) return null
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf, RATE)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return null
        }
        val out = ShortArray(total)
        try {
            rec.startRecording()
            var n = 0
            while (n < total) {
                val r = rec.read(out, n, total - n)
                if (r <= 0) return null
                n += r
            }
        } finally {
            runCatching { rec.stop() }
            rec.release()
        }
        return out
    }

    // ------------------------------------------------------------- features

    private val window = FloatArray(FRAME) {
        (0.54 - 0.46 * cos(2 * PI * it / (FRAME - 1))).toFloat()
    }

    private val melBank: Array<FloatArray> = buildMel()

    private val dct: Array<FloatArray> = Array(COEFS) { k ->
        FloatArray(MELS) { n -> cos(PI * k * (n + 0.5) / MELS).toFloat() }
    }

    private fun hz2mel(h: Double) = 2595.0 * log10(1.0 + h / 700.0)
    private fun mel2hz(m: Double) = 700.0 * (10.0.pow(m / 2595.0) - 1.0)

    private fun buildMel(): Array<FloatArray> {
        val low = hz2mel(100.0)
        val high = hz2mel(7600.0)
        val pts = DoubleArray(MELS + 2) { mel2hz(low + (high - low) * it / (MELS + 1)) }
        val bins = IntArray(MELS + 2) { floor((NFFT + 1) * pts[it] / RATE).toInt() }
        return Array(MELS) { m ->
            val f = FloatArray(NFFT / 2 + 1)
            val up = (bins[m + 1] - bins[m]).coerceAtLeast(1)
            val down = (bins[m + 2] - bins[m + 1]).coerceAtLeast(1)
            for (k in bins[m] until bins[m + 1]) f[k] = (k - bins[m]).toFloat() / up
            for (k in bins[m + 1] until bins[m + 2]) f[k] = (bins[m + 2] - k).toFloat() / down
            f
        }
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang).toFloat()
            val wi = sin(ang).toFloat()
            val half = len / 2
            var i = 0
            while (i < n) {
                var cr = 1f
                var ci = 0f
                for (k in 0 until half) {
                    val ur = re[i + k]
                    val ui = im[i + k]
                    val vr = re[i + k + half] * cr - im[i + k + half] * ci
                    val vi = re[i + k + half] * ci + im[i + k + half] * cr
                    re[i + k] = ur + vr
                    im[i + k] = ui + vi
                    re[i + k + half] = ur - vr
                    im[i + k + half] = ui - vi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }

    /** MFCC frames of the spoken part only, normalised per recording. Empty array = no clear speech. */
    fun features(pcm: ShortArray): Array<FloatArray> {
        val x = FloatArray(pcm.size) { i ->
            val cur = pcm[i] / 32768f
            val prev = if (i > 0) pcm[i - 1] / 32768f else 0f
            cur - 0.97f * prev
        }
        val nFrames = (x.size - FRAME) / HOP + 1
        if (nFrames <= 0) return emptyArray()

        val energy = FloatArray(nFrames)
        val raw = ArrayList<FloatArray>(nFrames)
        val re = FloatArray(NFFT)
        val im = FloatArray(NFFT)
        val mel = FloatArray(MELS)

        for (f in 0 until nFrames) {
            Arrays.fill(re, 0f)
            Arrays.fill(im, 0f)
            var e = 0f
            for (i in 0 until FRAME) {
                val v = x[f * HOP + i] * window[i]
                re[i] = v
                e += v * v
            }
            energy[f] = e
            fft(re, im)
            for (m in 0 until MELS) {
                var s = 0f
                val fb = melBank[m]
                for (k in 0..NFFT / 2) {
                    if (fb[k] != 0f) s += fb[k] * (re[k] * re[k] + im[k] * im[k])
                }
                mel[m] = ln(s + 1e-10f)
            }
            raw.add(FloatArray(COEFS - 1) { k ->
                var s = 0f
                for (n in 0 until MELS) s += dct[k + 1][n] * mel[n]
                s
            })
        }

        // keep only the span where someone is actually speaking
        val thr = energy.max() * 0.01f
        val first = energy.indexOfFirst { it > thr }
        val last = energy.indexOfLast { it > thr }
        if (first < 0 || last - first < 20) return emptyArray()
        val seg = raw.subList(first, last + 1)

        // mean/variance normalisation (removes mic and volume differences)
        val d = COEFS - 1
        val mean = FloatArray(d)
        val std = FloatArray(d)
        for (fr in seg) for (k in 0 until d) mean[k] += fr[k] / seg.size
        for (fr in seg) for (k in 0 until d) std[k] += (fr[k] - mean[k]) * (fr[k] - mean[k]) / seg.size
        return Array(seg.size) { i ->
            FloatArray(d) { k -> (seg[i][k] - mean[k]) / (sqrt(std[k]) + 1e-6f) }
        }
    }

    // ------------------------------------------------------------- matching

    private fun frameDist(a: FloatArray, b: FloatArray): Float {
        var s = 0f
        for (i in a.indices) {
            val d = a[i] - b[i]
            s += d * d
        }
        return sqrt(s)
    }

    fun distance(a: Array<FloatArray>, b: Array<FloatArray>): Float {
        val n = a.size
        val m = b.size
        val inf = Float.MAX_VALUE / 2
        var prev = FloatArray(m + 1) { inf }
        var cur = FloatArray(m + 1)
        prev[0] = 0f
        for (i in 1..n) {
            cur[0] = inf
            for (j in 1..m) {
                cur[j] = frameDist(a[i - 1], b[j - 1]) + minOf(prev[j], prev[j - 1], cur[j - 1])
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[m] / (n + m)
    }

    fun calibrate(templates: List<Array<FloatArray>>): Float {
        var worst = 0f
        for (i in templates.indices) for (j in i + 1 until templates.size) {
            worst = maxOf(worst, distance(templates[i], templates[j]))
        }
        Log.d(TAG, "voice calibration: worst own distance = $worst")
        return worst * MARGIN
    }

    fun matches(c: Context, pcm: ShortArray): Boolean {
        val (templates, threshold) = Store.loadVoice(c) ?: return false
        val f = features(pcm)
        if (f.isEmpty()) return false
        val best = templates.minOf { distance(it, f) }
        Log.d(TAG, "voice distance = $best, threshold = $threshold")
        return best <= threshold
    }
}
