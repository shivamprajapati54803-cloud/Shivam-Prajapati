package com.faceguard.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Foreground service: watches the front camera while the screen is on,
 * compares every face with the saved owner face, and raises the alert for strangers.
 */
class GuardService : LifecycleService() {

    private lateinit var exec: ExecutorService
    private lateinit var matcher: FaceMatcher
    private lateinit var detector: FaceDetector
    private var provider: ProcessCameraProvider? = null
    private var badge: TextView? = null
    private var badgeBg: GradientDrawable? = null
    private var blackout: View? = null
    private val main = Handler(Looper.getMainLooper())

    private var owner: List<FloatArray> = emptyList()
    private var enrolling = false
    private val enrollSamples = mutableListOf<FloatArray>()

    private var lastAnalyze = 0L
    private var strangerCount = 0
    private var ownerCount = 0
    private var lastAlertAt = 0L

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> unbindCamera()
                Intent.ACTION_SCREEN_ON -> bindCamera()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        exec = Executors.newSingleThreadExecutor()
        matcher = FaceMatcher(this)
        detector = FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .build()
        )
        owner = Store.loadOwner(this)
        startInForeground()
        showBadge()
        ContextCompat.registerReceiver(
            this, screenReceiver,
            IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        bindCamera()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_ENROLL) {
            enrollSamples.clear()
            enrolling = true
            toast("कैमरा की तरफ सीधे देखिए...")
        }
        return START_STICKY
    }

    // ---------------------------------------------------------------- camera

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                p.unbindAll()
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(exec) { analyze(it) }
                p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                Log.e(TAG, "camera bind failed", e)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun unbindCamera() {
        provider?.unbindAll()
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastAnalyze < ANALYZE_EVERY_MS) return
            lastAnalyze = now

            val bmp = rotate(proxy.toBitmap(), proxy.imageInfo.rotationDegrees)
            val faces = Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0)))
            if (faces.isEmpty()) {
                strangerCount = 0
                setBadge(COLOR_NO_FACE)
                hideBlackout()
                return
            }

            val r = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }!!.boundingBox
            val x = r.left.coerceIn(0, bmp.width - 1)
            val y = r.top.coerceIn(0, bmp.height - 1)
            val w = r.width().coerceAtMost(bmp.width - x)
            val h = r.height().coerceAtMost(bmp.height - y)
            if (w < 60 || h < 60) return

            val emb = matcher.embed(Bitmap.createBitmap(bmp, x, y, w, h))

            if (enrolling) {
                enrollSamples += emb
                if (enrollSamples.size >= ENROLL_SAMPLES) finishEnroll()
                return
            }
            if (owner.isEmpty()) return

            val score = owner.maxOf { FaceMatcher.cosine(it, emb) }
            Log.d(TAG, "match score = $score")

            if (score >= THRESHOLD) {
                ownerCount++
                strangerCount = 0
                setBadge(COLOR_OWNER)
                hideBlackout()
                if (ownerCount >= 2) AlertActivity.dismissFromService()
            } else {
                ownerCount = 0
                strangerCount++
                setBadge(COLOR_WATCHING)
                // Go black right away; the full alert follows after a few frames
                if (!AlertActivity.active) showBlackout()
                if (strangerCount >= STRANGER_FRAMES) onStranger(bmp)
            }
        } catch (e: Exception) {
            Log.e(TAG, "analyze failed", e)
        } finally {
            proxy.close()
        }
    }

    private fun rotate(b: Bitmap, deg: Int): Bitmap {
        if (deg == 0) return b
        val m = Matrix().apply { postRotate(deg.toFloat()) }
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    // ------------------------------------------------------------ enrollment

    private fun finishEnroll() {
        enrolling = false
        Store.saveOwner(this, enrollSamples.toList())
        owner = Store.loadOwner(this)
        toast("आपका चेहरा सेव हो गया ✅")
    }

    // ---------------------------------------------------------------- alert

    private fun onStranger(photo: Bitmap) {
        strangerCount = 0
        val now = SystemClock.elapsedRealtime()
        if (AlertActivity.active || now - lastAlertAt < ALERT_COOLDOWN_MS) return
        lastAlertAt = now

        // 1. Save the stranger's photo (private app storage)
        try {
            val dir = File(filesDir, "intruders").apply { mkdirs() }
            File(dir, "${System.currentTimeMillis()}.jpg").outputStream().use {
                photo.compress(Bitmap.CompressFormat.JPEG, 85, it)
            }
        } catch (e: Exception) {
            Log.e(TAG, "save photo failed", e)
        }

        main.post {
            // 2. Close whatever app is open
            GuardAccessibility.goHome()
            // 3. Show the warning page + alarm + voice
            startActivity(
                Intent(this, AlertActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
            // Lift the black cover so the red warning page is visible
            main.postDelayed({ hideBlackout() }, 400)
        }
    }

    // ------------------------------------------------------------ small bits

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("guard", "FaceGuard", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, "guard")
            .setContentTitle("FaceGuard चालू है")
            .setContentText("आपके फोन की निगरानी हो रही है")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
    }

    /**
     * Round "Security" badge at the top, always above other apps.
     * Red = watching, green = owner recognised, amber = nobody in front of the camera.
     */
    private fun showBadge() {
        if (!Settings.canDrawOverlays(this)) return
        val d = resources.displayMetrics.density
        val bg = GradientDrawable().apply {
            cornerRadius = 40 * d
            setColor(COLOR_WATCHING)
        }
        val v = TextView(this).apply {
            text = "🔒 Security"
            textSize = 11f
            setTextColor(Color.WHITE)
            setPadding((10 * d).toInt(), (4 * d).toInt(), (10 * d).toInt(), (4 * d).toInt())
            background = bg
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (24 * d).toInt()
        }
        (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp)
        badge = v
        badgeBg = bg
    }

    private fun setBadge(color: Int) {
        main.post { badgeBg?.setColor(color) }
    }

    /** Instantly covers the whole screen in black and swallows all touches. */
    private fun showBlackout() {
        main.post {
            if (blackout != null || !Settings.canDrawOverlays(this)) return@post
            val v = View(this).apply { setBackgroundColor(Color.BLACK) }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.OPAQUE
            )
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp)
            blackout = v
        }
    }

    private fun hideBlackout() {
        main.post {
            blackout?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
            blackout = null
        }
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() {
        unbindCamera()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        badge?.let { wm.removeView(it) }
        blackout?.let { wm.removeView(it) }
        runCatching { unregisterReceiver(screenReceiver) }
        exec.shutdown()
        detector.close()
        matcher.close()
        super.onDestroy()
    }

    companion object {
        const val ACTION_ENROLL = "com.faceguard.app.ENROLL"
        private const val TAG = "FaceGuard"
        private val COLOR_WATCHING = Color.parseColor("#D32F2F")
        private val COLOR_OWNER = Color.parseColor("#2E7D32")
        private val COLOR_NO_FACE = Color.parseColor("#F57C00")

        /** Cosine similarity needed to count as the owner. Tune 0.5 to 0.7 for your model/lighting. */
        private const val THRESHOLD = 0.55f
        private const val ANALYZE_EVERY_MS = 600L
        private const val STRANGER_FRAMES = 3
        private const val ENROLL_SAMPLES = 8
        private const val ALERT_COOLDOWN_MS = 10_000L
    }
}
