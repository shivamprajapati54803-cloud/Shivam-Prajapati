package com.faceguard.app

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 80, 40, 40)
        }
        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, 32) }
        root.addView(status)

        fun button(label: String, action: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                setOnClickListener { action() }
            })
        }

        button("1. कैमरा, माइक और नोटिफिकेशन की अनुमति") {
            permLauncher.launch(
                arrayOf(
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.POST_NOTIFICATIONS
                )
            )
        }
        button("2. ऊपर दिखने की अनुमति (Overlay)") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("3. Accessibility चालू करें (FaceGuard)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("4. बैटरी रोक हटाएँ") {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        }
        button("5. PIN सेट करें") { askPin() }
        button("6. मेरा चेहरा सेव करें") { enroll() }
        button("7. मेरी आवाज़ सेव करें (बैकअप)") { enrollVoice() }
        button("▶ गार्ड चालू करें") { startGuard() }
        button("■ गार्ड बंद करें") {
            stopService(Intent(this, GuardService::class.java))
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun hasCamera() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun accessibilityOn(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        return enabled?.contains(packageName) == true
    }

    private fun refresh() {
        fun mark(ok: Boolean) = if (ok) "✅" else "❌"
        status.text = buildString {
            appendLine("कैमरा अनुमति: ${mark(hasCamera())}")
            appendLine("Overlay अनुमति: ${mark(Settings.canDrawOverlays(this@MainActivity))}")
            appendLine("Accessibility: ${mark(accessibilityOn())}")
            appendLine("PIN: ${mark(Store.hasPin(this@MainActivity))}")
            appendLine("मेरा चेहरा सेव: ${mark(Store.hasOwner(this@MainActivity))}")
            append("मेरी आवाज़ सेव: ${mark(Store.hasVoice(this@MainActivity))}")
        }
    }

    private fun askPin() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "कम से कम 4 अंक"
        }
        AlertDialog.Builder(this)
            .setTitle("नया PIN")
            .setView(input)
            .setPositiveButton("सेव") { _, _ ->
                val pin = input.text.toString()
                if (pin.length >= 4) {
                    Store.setPin(this, pin)
                    refresh()
                } else {
                    Toast.makeText(this, "PIN कम से कम 4 अंक का हो", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("रद्द", null)
            .show()
    }

    private fun enroll() {
        if (!hasCamera()) {
            Toast.makeText(this, "पहले कैमरा की अनुमति दें", Toast.LENGTH_SHORT).show()
            return
        }
        ContextCompat.startForegroundService(
            this,
            Intent(this, GuardService::class.java).setAction(GuardService.ACTION_ENROLL)
        )
        // Refresh after the ~5 seconds enrollment takes
        status.postDelayed({ refresh() }, 6000)
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** Owner says the same short phrase 3 times; the app learns how it sounds. */
    private fun enrollVoice() {
        if (!hasMic()) {
            permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            toast("माइक की अनुमति दें, फिर यह बटन दोबारा दबाएँ")
            return
        }
        val rounds = 3
        val templates = mutableListOf<Array<FloatArray>>()

        fun round(i: Int) {
            AlertDialog.Builder(this)
                .setTitle("आवाज़ सेव ($i/$rounds)")
                .setMessage("\"रिकॉर्ड\" दबाते ही 3 सेकंड में एक छोटा वाक्य बोलें, जैसे \"मैं इस फोन का मालिक हूँ\"। हर बार वही वाक्य, उसी तरह।")
                .setCancelable(false)
                .setPositiveButton("रिकॉर्ड") { _, _ ->
                    toast("🎤 बोलिए...")
                    Thread {
                        val pcm = VoicePrint.record()
                        val f = pcm?.let { VoicePrint.features(it) }
                        runOnUiThread {
                            if (f == null || f.isEmpty()) {
                                toast("आवाज़ साफ़ नहीं आई, फिर कोशिश करें")
                                round(i)
                            } else {
                                templates.add(f)
                                if (i < rounds) round(i + 1) else finishVoice(templates)
                            }
                        }
                    }.start()
                }
                .setNegativeButton("रद्द", null)
                .show()
        }
        round(1)
    }

    private fun finishVoice(t: List<Array<FloatArray>>) {
        Store.saveVoice(this, t, VoicePrint.calibrate(t))
        toast("आपकी आवाज़ सेव हो गई ✅")
        refresh()
    }

    private fun startGuard() {
        when {
            !hasCamera() -> toast("पहले कैमरा की अनुमति दें")
            !Store.hasOwner(this) -> toast("पहले अपना चेहरा सेव करें")
            !Store.hasPin(this) -> toast("पहले PIN सेट करें")
            else -> ContextCompat.startForegroundService(this, Intent(this, GuardService::class.java))
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
