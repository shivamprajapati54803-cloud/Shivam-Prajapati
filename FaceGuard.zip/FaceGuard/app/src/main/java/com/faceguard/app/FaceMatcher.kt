package com.faceguard.app

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.sqrt

/**
 * Turns a cropped face into an embedding using a MobileFaceNet TFLite model.
 * Expected model: input 1x112x112x3 float, output 1xN float (usually N = 192).
 * Put the file at app/src/main/assets/mobilefacenet.tflite
 */
class FaceMatcher(ctx: Context) {
    private val interpreter: Interpreter
    private val outDim: Int
    private val inSize: Int

    init {
        val fd = ctx.assets.openFd(MODEL)
        val buf = FileInputStream(fd.fileDescriptor).channel
            .map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
        interpreter = Interpreter(buf, Interpreter.Options().setNumThreads(2))
        outDim = interpreter.getOutputTensor(0).shape()[1]
        inSize = interpreter.getInputTensor(0).shape()[1] // 112 (MobileFaceNet) or 160 (FaceNet)
    }

    fun embed(face: Bitmap): FloatArray {
        val s = inSize
        val bmp = Bitmap.createScaledBitmap(face, s, s, true)
        val px = IntArray(s * s)
        bmp.getPixels(px, 0, s, 0, 0, s, s)
        val v = FloatArray(s * s * 3)
        var i = 0
        for (p in px) {
            v[i++] = ((p shr 16) and 0xFF).toFloat()
            v[i++] = ((p shr 8) and 0xFF).toFloat()
            v[i++] = (p and 0xFF).toFloat()
        }
        if (s == 160) {
            // FaceNet: per-image standardisation
            var mean = 0f
            for (x in v) mean += x
            mean /= v.size
            var varSum = 0f
            for (x in v) varSum += (x - mean) * (x - mean)
            val std = maxOf(sqrt(varSum / v.size), 1f / sqrt(v.size.toFloat()))
            for (k in v.indices) v[k] = (v[k] - mean) / std
        } else {
            // MobileFaceNet: (x - 127.5) / 128
            for (k in v.indices) v[k] = (v[k] - 127.5f) / 128f
        }
        val input = ByteBuffer.allocateDirect(4 * v.size).order(ByteOrder.nativeOrder())
        for (x in v) input.putFloat(x)
        input.rewind()
        val out = Array(1) { FloatArray(outDim) }
        interpreter.run(input, out)
        return normalize(out[0])
    }

    fun close() = interpreter.close()

    companion object {
        private const val MODEL = "mobilefacenet.tflite"
        private const val SIZE = 112

        private fun normalize(v: FloatArray): FloatArray {
            var n = 0f
            for (x in v) n += x * x
            n = sqrt(n).coerceAtLeast(1e-6f)
            return FloatArray(v.size) { v[it] / n }
        }

        /** Both vectors are already L2-normalised, so the dot product is the cosine similarity. */
        fun cosine(a: FloatArray, b: FloatArray): Float {
            var d = 0f
            for (i in a.indices) d += a[i] * b[i]
            return d
        }
    }
}
